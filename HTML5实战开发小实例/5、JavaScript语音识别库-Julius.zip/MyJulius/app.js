/**
 * Created by wwtliu on 14/10/9.
 */
var julius = new Julius();
julius.onrecognition = function(content){
    console.log("内容:",content);
    document.getElementById("what-you-said").innerHTML = content;
}
julius.onfirstpass = function(content){
    console.log("firstpass:",content);
}
julius.onfail = function(){
    console.log("失败");
}
julius.onlog = function(log){
    console.log(log);
}