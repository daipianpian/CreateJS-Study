# White Paper: HTML5 Banner Ads With CreateJS
An in-depth white paper on building HTML5 advertising with CreateJS and Flash Pro. Includes supporting materials, sample banner ad, and helper classes.

The document can be read online at:
[http://createjs.com/html5ads/](http://createjs.com/html5ads/)

The AdHelper directory includes the AdHelper class, and an example banner ad created with Flash Professional CC.