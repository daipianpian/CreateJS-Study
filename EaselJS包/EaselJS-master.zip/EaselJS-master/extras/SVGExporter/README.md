# SVGExporter

Exports any EaselJS stage (or container) to SVG. Currently experimental, not extensively tested.

Supports most features of EaselJS, including vector art, sprites, text, and bitmaps. Read the documentation in the SVGExporter.js file for full details.

Check out the SVGExport.html file for example usage.