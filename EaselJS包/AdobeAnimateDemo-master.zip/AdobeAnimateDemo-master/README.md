# AdobeAnimateDemo
Mini game with visual assets created in Adobe Animate CC by [@gskinner](https://twitter.com/gskinner) and [@mike_gaboury](https://twitter.com/mike_gaboury) in 6 hours for the Adobe Creative Twitch stream.

All assets except the sounds are licensed under MIT. Sounds are from:
https://freesound.org/

The game is hosted here:
http://gskinner.com/playpen/AdobeAnimateDemo/index.html

A recording of the live stream is available in three parts:

1. http://www.twitch.tv/adobe/v/28006412?t=06h53m01s
2. http://www.twitch.tv/adobe/v/28071871?t=05h04m20s
3. http://www.twitch.tv/adobe/v/28248339?t=02h55m29s