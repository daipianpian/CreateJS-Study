Kaleidoscope
=======

Simple class to easily draw configurable kaleidoscopes using any DisplayObject as a source in EaselJS.

![ScreenShot](https://raw.github.com/CreateJS/sandbox/master/Kaleidoscope/README_1.jpg)

**[View this example online.](http://sandbox.createjs.com/Kaleidoscope/demo.html)**